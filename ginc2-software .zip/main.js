// Placeholder for interactivity
console.log("Welcome to Ginc ");
